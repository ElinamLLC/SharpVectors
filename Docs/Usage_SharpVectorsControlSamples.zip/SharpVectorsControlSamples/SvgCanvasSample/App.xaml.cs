﻿using System;

using System.Windows;

namespace SvgCanvasSample
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
