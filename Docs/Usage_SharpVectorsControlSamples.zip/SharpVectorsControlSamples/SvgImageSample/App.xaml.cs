﻿using System;

using System.Windows;

namespace SvgImageSample
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
